axes:
  e:
    inverted: false
    speed: 10000
  x:
    inverted: false
    speed: 9000
  y:
    inverted: false
    speed: 9000
  z:
    inverted: false
    speed: 500
color: default
extruder:
  count: 1
  defaultExtrusionLength: 5
  nozzleDiameter: 0.4
  offsets:
  - - 0.0
    - 0.0
  sharedNozzle: false
heatedBed: true
heatedChamber: false
id: _default
model: MK2.5S
name: Original Prusa i3 MK2.5S Bear
volume:
  custom_box:
    x_max: 250.0
    x_min: 0.0
    y_max: 210.0
    y_min: -3.0
    z_max: 200.0
    z_min: 0.0
  depth: 210.0
  formFactor: rectangular
  height: 200.0
  origin: lowerleft
  width: 250.0
